<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container">
    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <div class="collapse navbar-collapse navHeaderCollapse">
      <ul class="nav navbar-nav navbar-right" id="navigation">
        <li>
          <a href="index.php">Početna</a>
        </li>
        <li>
          <a href="galerija.php">Galerija</a>
        </li>
        <li>
           <a href="zivotopis.php">Izložbe i nagrade</a>
        </li>
        <li>
          <a href="contact.php">Kontakt</a>
        </li>
      </ul>
    </div>
  </div>
</nav>